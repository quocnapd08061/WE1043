const slider = document.querySelector('.slider');
const prevBtn = document.querySelector('.prev-slide');
const nextBtn = document.querySelector('.next-slide');
let slideIndex = 0;

function showSlide(n) {
  const slides = slider.querySelectorAll('img');
  if (n < 0) {
    slideIndex = slides.length - 1;
  } else if (n >= slides.length) {
    slideIndex = 0;
  }
  for (let i = 0; i < slides.length; i++) {
    slides[i].style.display = 'none';
  }
  slides[slideIndex].style.display = 'block';
}

showSlide(slideIndex);

prevBtn.addEventListener('click', () => {
  slideIndex--;
  showSlide(slideIndex);
});

nextBtn.addEventListener('click', () => {
  slideIndex++;
  showSlide(slideIndex);
});

