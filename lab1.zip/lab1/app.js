// Yêu cầu người dùng nhập 2 số nguyên a và b từ bàn phím
x
let b = parseInt(prompt("Nhập số nguyên b: "));

// Tính tổng của a và b
let c = a + b;

// In ra kết quả bằng phương thức document.write và console.log
document.write("Tổng của " + a + " và " + b + " là " + c);
console.log("Tổng của " + a + " và " + b + " là  " + c);x``
